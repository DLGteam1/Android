package com.MobileAnarchy.Android.Widgets.Joystick;

public interface JoystickClickedListener {
	public void OnClicked();
	public void OnReleased();
}
